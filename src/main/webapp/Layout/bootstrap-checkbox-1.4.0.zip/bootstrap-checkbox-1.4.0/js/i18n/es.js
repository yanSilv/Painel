'use strict';

(function($) {
  $.extend($.fn.checkboxpicker.defaults, {
    offLabel: 'No',
    onLabel: 'Si',
    warningMessage: 'Por favor, no utilice Bootstrap-checkbox para elementos tipo label.'
  });
})(jQuery);
